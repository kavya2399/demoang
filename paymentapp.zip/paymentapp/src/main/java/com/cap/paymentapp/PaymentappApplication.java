package com.cap.paymentapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaymentappApplication {

	public static void main(String[] args) {
		SpringApplication.run(PaymentappApplication.class, args);
	}

}
